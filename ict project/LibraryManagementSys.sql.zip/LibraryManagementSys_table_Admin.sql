
-- --------------------------------------------------------

--
-- Table structure for table `Admin`
--

DROP TABLE IF EXISTS `Admin`;
CREATE TABLE `Admin` (
  `Admin_ID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Created_At` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Admin`
--

INSERT INTO `Admin` (`Admin_ID`, `Username`, `Password`, `Email`, `Created_At`) VALUES
(1, 'new_admin', 'hashed_password', 'new_admin@example.com', '2024-11-04 22:04:02'),
(2, 'admin', 'admin', 'admin@example.com', '2024-11-08 19:13:56'),
(3, 'sksalitha', 'sksalitha1234', 'sksalitha@gmail.com', '2024-11-09 17:53:17'),
(4, 'root', 'root', 'root@gmail.com', '2024-11-10 18:18:05'),
(5, 'superuser', 'root', 'root@gmail.com', '2024-11-10 18:27:50');
