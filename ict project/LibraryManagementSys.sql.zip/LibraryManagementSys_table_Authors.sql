
-- --------------------------------------------------------

--
-- Table structure for table `Authors`
--

DROP TABLE IF EXISTS `Authors`;
CREATE TABLE `Authors` (
  `Author_ID` int(11) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Authors`
--

INSERT INTO `Authors` (`Author_ID`, `First_Name`, `Last_Name`) VALUES
(1, 'J.K.', 'Rowling'),
(2, 'sahan', 'kaushalya'),
(3, 'sahan', 'kaushalya'),
(4, 'sahan', 'kaushalya'),
(5, 'sahan', 'kaushalya'),
(6, 'sahan', 'kaushalya'),
(7, 'sahan', 'kaushalya'),
(8, 'sahan', 'kaushalya'),
(9, 'sahan', 'kaushalya'),
(10, 'sahan', 'kaushalya'),
(11, 'dilshan', 'fenando'),
(12, 'ssss', 'dfdddd'),
(13, 'ssss', 'dfdddd'),
(14, 'ssss', 'dfdddd'),
(15, 'sdfsdf', 'sdsf'),
(16, 'sdfsdf', 'sdsf'),
(17, 'sdfsdf', 'sdsf'),
(18, 'sdfsdf', 'sdsf'),
(19, 'sdfsdf', 'sdsf'),
(20, 'sahan', 'sahan'),
(21, 'Harper', 'Lee'),
(22, 'J.R.R.', 'Tolkien'),
(23, 'Anne', 'Frank'),
(24, 'Dan', 'Brown'),
(25, 'jhon', 'kn');
