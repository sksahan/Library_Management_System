
-- --------------------------------------------------------

--
-- Table structure for table `Books`
--

DROP TABLE IF EXISTS `Books`;
CREATE TABLE `Books` (
  `Book_ID` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Author_ID` int(11) DEFAULT NULL,
  `Category_ID` int(11) DEFAULT NULL,
  `Publisher` varchar(100) DEFAULT NULL,
  `Year_Published` year(4) DEFAULT NULL,
  `ISBN` varchar(20) DEFAULT NULL,
  `Status` enum('Available','Issued') DEFAULT 'Available',
  `Quantity` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Books`
--

INSERT INTO `Books` (`Book_ID`, `Title`, `Author_ID`, `Category_ID`, `Publisher`, `Year_Published`, `ISBN`, `Status`, `Quantity`) VALUES
(2, 'java', 7, 7, 'abc', '2001', '1234', 'Available', 2),
(3, 'shaerlock', 7, 1, 'abc', '2001', '5654', 'Available', 2),
(4, 'dss', 7, 12, 'abc', '2001', '3345334553', 'Available', 1),
(5, 'sdssfffg', 7, 5, 'abc', '2001', '23244', 'Available', 2),
(6, 'skkk', 7, 5, 'abc', '2001', '45643232', 'Available', 2),
(7, 'java', 7, 12, 'abc', '2001', '123456', 'Available', 1),
(8, 'To Kill a Mockingbird', 21, 1, 'J.B. Lippincott & Co.', '1960', '9780061120084', 'Available', 10),
(9, 'Harry Potter and the Sorcerer\'s Stone', 1, 5, 'Bloomsbury', '1997', '9780439554930', 'Available', 5),
(10, 'The Hobbit', 22, 5, 'George Allen & Unwin', '1937', '9780547928227', 'Available', 7),
(11, 'The Diary of a Young Girl', 23, 7, 'Contact Publishing', '1947', '9780553296983', 'Available', 3),
(12, 'The Da Vinci Code', 24, 16, 'Doubleday', '2003', '9780385504201', 'Available', 10),
(13, 'java programin', 25, 11, 'sd', '2001', '2323', 'Available', 2);
