
-- --------------------------------------------------------

--
-- Table structure for table `Categories`
--

DROP TABLE IF EXISTS `Categories`;
CREATE TABLE `Categories` (
  `Category_ID` int(11) NOT NULL,
  `Category_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Categories`
--

INSERT INTO `Categories` (`Category_ID`, `Category_Name`) VALUES
(17, 'Adventure'),
(18, 'Anthology'),
(7, 'Biography'),
(11, 'Children'),
(65, 'Classic'),
(19, 'Classic Literature'),
(66, 'Coming-of-Age'),
(12, 'Cookbooks'),
(20, 'Dystopian'),
(5, 'Fantasy'),
(1, 'Fiction'),
(14, 'Graphic Novels'),
(21, 'Historical Fiction'),
(9, 'History'),
(22, 'Horror'),
(23, 'Literary Fiction'),
(24, 'Memoir'),
(6, 'Mystery'),
(25, 'Mystery Thriller'),
(3, 'Non-Fiction'),
(67, 'Philosophy'),
(15, 'Poetry'),
(68, 'Post-apocalyptic'),
(10, 'Romance'),
(26, 'Science'),
(4, 'Science Fiction'),
(8, 'Self-Help'),
(29, 'Self-Improvement'),
(27, 'Short Stories'),
(16, 'Thriller'),
(13, 'Travel'),
(28, 'Young Adult');
