
-- --------------------------------------------------------

--
-- Table structure for table `Members`
--

DROP TABLE IF EXISTS `Members`;
CREATE TABLE `Members` (
  `Member_ID` int(11) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Membership_Date` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Members`
--

INSERT INTO `Members` (`Member_ID`, `First_Name`, `Last_Name`, `Address`, `Phone`, `Email`, `Membership_Date`) VALUES
(1, 'John', 'Doe', '123 Main St', '123-456-7890', 'john.doe@example.com', '2024-11-05'),
(2, 'sahan', 'kaushalya', 'sahan niwasa piyarapandowa', '0781188002', 'sahankaushalya1234@gmail.com', '2024-11-09'),
(3, 'kavinda', 'ekanayake', 'kandy 103', '0763708504', 'kavinda12@gmail.com', '2024-11-09'),
(4, 'hanifa', 'safran', 'mahawa 123', '0776612314', 'safa1234@gmail.com', '2024-11-10'),
(5, 'dinushan', 'thathmila', 'kubalwela ella', '0763708504', 'dinushan12@gmail.com', '2024-11-10');
