
-- --------------------------------------------------------

--
-- Table structure for table `Transactions`
--

DROP TABLE IF EXISTS `Transactions`;
CREATE TABLE `Transactions` (
  `Transaction_ID` int(11) NOT NULL,
  `Book_ID` int(11) DEFAULT NULL,
  `Member_ID` int(11) DEFAULT NULL,
  `Issue_Date` date DEFAULT curdate(),
  `Return_Date` date DEFAULT NULL,
  `Fine` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Transactions`
--

INSERT INTO `Transactions` (`Transaction_ID`, `Book_ID`, `Member_ID`, `Issue_Date`, `Return_Date`, `Fine`) VALUES
(10, 3, 2, '2024-11-10', '2024-11-10', 0.00),
(11, 3, 2, '2024-11-10', '2024-11-10', 0.00),
(12, 3, 2, '2024-11-10', '2024-11-10', 0.00),
(13, 2, 2, '2024-11-10', '2024-11-10', 0.00),
(16, 3, 2, '2024-11-10', '2024-11-10', 0.00),
(23, 4, 2, '2024-11-10', NULL, 0.00),
(25, 7, 2, '2024-11-10', '2024-11-10', 0.00),
(26, 7, 2, '2024-11-10', '2024-11-10', 0.00),
(29, 7, 2, '2024-11-10', NULL, 0.00),
(34, 2, 2, '2024-11-10', '2024-11-10', 0.00),
(36, 12, 5, '2024-11-10', '2024-11-10', 0.00),
(37, 13, 5, '2024-11-10', '2024-11-10', 0.00);
